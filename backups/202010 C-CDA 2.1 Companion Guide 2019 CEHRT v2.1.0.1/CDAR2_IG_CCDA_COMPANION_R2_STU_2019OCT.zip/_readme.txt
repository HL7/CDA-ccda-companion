This readme file is included in a zip file which contains the Publication Package for:

Publication title:                               HL7 CDA� R2 IG: C-CDA Templates for Clinical Notes R2.1 Companion Guide, Release 2 - US Realm
Edition:                                         Release 2
Realm:                                           US Realm
Ballot type:                                     Standard for Trial Use (STU)
Code: 						 Release 2 STU 1
Version:                                         v2.1.0 
Errata identifier:                               2020-10-16 
Publication date:                                2019-10-28 
Prepared by:                                     Structure Document Work Group (


Contents of the Publication Package
====================================

This file:                                       _readme.txt 

                                -- Errata files --    
List of errata identified to be applied:         _CDA Errata Letter 20201016 signed.pdf     

  
                                -- STU -- 
CDA R2.1 Companion Guidance:                         CDAR2_IG_CCDA_COMPANION_R2_STU_2019OCT.pdf
Additional C-CDA Templates:                          CDAR2_IG_CCDA_COMPANION_R2_STU_2019OCT_AppxA.pdf
UDI Organizer Template:                              CDAR2_IG_CCDA_COMPANION_R2_STU_2019OCT_AppxB.pdf
Provenance - Author Participation Template:          CDAR2_IG_CCDA_COMPANION_R2_STU_2019OCT_AppxC.pdf
                    
                                --- Sample files ---
Sample XML Files.zip

                                -- Support files --
Support files include related files that augment the specification but are not considered part of the specification such as transform/stylesheet and validation files.

                                --- Transform/Stylesheet files ---
HL7 International has a general purpose rendering stylesheet for CDA documents. The stylesheet comes without warranty and should be locally tested by implementers before production use.

CDA Stylesheet repository:                         https://github.com/HL7/cda-core-xsl
Latest version:                                    https://github.com/HL7/cda-core-xsl/releases/latest

                                --- Validation files ---

                                ---- Schema files ----
CDA R2.0 Normative Schema:                         https://github.com/HL7/cda-core-2.0/tree/master/schema/normative
CDA R2.0 sdtc Extended Schema:                     https://github.com/HL7/cda-core-2.0/tree/master/schema/extensions

                                ---- Schematron files ----
C-CDA 2.1 Companion Guide R2 Schematrons.zip
Consolidated CDA Templates for Clinical Notes (US Realm) DSTU R2.1 Schematron.zip

