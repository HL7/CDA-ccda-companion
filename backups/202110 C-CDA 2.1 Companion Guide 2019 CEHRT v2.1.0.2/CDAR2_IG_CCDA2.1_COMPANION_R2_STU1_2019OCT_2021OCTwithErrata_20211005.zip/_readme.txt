Publication title:                               HL7 CDA� R2 IG: C-CDA Templates for Clinical Notes R2.1 Companion Guide, Release 2 - US Realm
Edition:                                         Release 2 STU 1
Realm:                                           US Realm
Release status:                                  Standard for Trial Use (STU)
JIRA Specification key:                          cda-ccda-companion-guide
Version:                                         2.1.0.2
Errata identifier:                               2021OCTwithErrata
Publication date:                                2019-10
Prepared by:                                     Structured Documents Work Group, the Federal Electronic Health Record Modernization (FEHRM) Program Office, and the US Realm Program Management Office


Contents of the package:
========================
This file:                                       _readme.txt 

--- Errata files ---
List of errata identified to be applied:	 2021OCT_C-CDACompanionGuideR2_Errata_list.xlsx
HL7 CTO Errata Letter:			         CTO_Errata_Letter_C-CDACompanionGuideR2_2021OCT.pdf     

  
--- STU ---
CDA R2.1 Companion Guidance:                     CDAR2_IG_CCDA2.1_COMPANION_R2_STU1_2019OCT_2021OCTwithErrata.pdf
Additional C-CDA Templates:                      CDAR2_IG_CCDA2.1_COMPANION_R2_STU1_2019OCT_AppxA_2021OCTwithErrata.pdf
UDI Organizer Template:                          CDAR2_IG_CCDA2.1_COMPANION_R2_STU1_2019OCT_AppxB_2021OCTwithErrata.pdf
Provenance - Author Participation Template:      CDAR2_IG_CCDA2.1_COMPANION_R2_STU1_2019OCT_AppxC_2021OCTwithErrata.pdf

--- Sample files ---
Sample file is stored at: https://github.com/HL7/cda-ccda-companion/

--- Transform/Stylesheet files ---
https://hl7.org/permalink/?CDAStyleSheet

---- Schema files ----
https://hl7.org/permalink/?CDAR2.0schema

---- Schematron Validation files ----
Schematron files are stored at: https://github.com/HL7/cda-ccda-companion/